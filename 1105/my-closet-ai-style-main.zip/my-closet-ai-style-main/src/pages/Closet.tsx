import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Shirt, ShoppingBag, Glasses, ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";

const Closet = () => {
  const navigate = useNavigate();
  const [items] = useState<any[]>([]);

  const categories = [
    { id: "all", label: "전체", icon: ShoppingBag },
    { id: "top", label: "상의", icon: Shirt },
    { id: "bottom", label: "하의", icon: Shirt },
    { id: "outer", label: "아우터", icon: Shirt },
    { id: "accessories", label: "액세서리", icon: Glasses },
  ];

  return (
    <div className="min-h-screen bg-background">
      <nav className="border-b border-border">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <Button variant="ghost" onClick={() => navigate("/")} className="mr-4">
                <ArrowLeft className="mr-2 h-4 w-4" />
                돌아가기
              </Button>
              <h1 className="text-xl font-bold tracking-tight">오늘 뭐 입지?</h1>
            </div>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              새 옷 추가
            </Button>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-12">
        <h2 className="text-4xl font-bold mb-2">내 옷장</h2>
        <p className="text-muted-foreground mb-12">등록된 옷으로 코디를 추천받을 수 있어요</p>

        <Tabs defaultValue="all" className="w-full">
          <TabsList className="w-full justify-start mb-8 h-12 bg-transparent border-b border-border rounded-none p-0">
            {categories.map((cat) => (
              <TabsTrigger 
                key={cat.id} 
                value={cat.id} 
                className="gap-2 rounded-none border-b-2 border-transparent data-[state=active]:border-foreground data-[state=active]:bg-transparent"
              >
                <cat.icon className="h-4 w-4" />
                {cat.label}
              </TabsTrigger>
            ))}
          </TabsList>

          {categories.map((cat) => (
            <TabsContent key={cat.id} value={cat.id}>
              {items.length === 0 ? (
                <div className="border border-dashed border-border rounded-none p-20 text-center">
                  <ShoppingBag className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-xl font-semibold mb-2">아직 등록된 옷이 없어요</h3>
                  <p className="text-muted-foreground mb-8">
                    첫 번째 아이템을 추가해보세요!
                  </p>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    옷 추가하기
                  </Button>
                </div>
              ) : (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-px bg-border">
                  {/* Items will be mapped here */}
                </div>
              )}
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </div>
  );
};

export default Closet;