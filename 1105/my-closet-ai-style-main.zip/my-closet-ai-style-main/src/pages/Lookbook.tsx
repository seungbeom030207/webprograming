import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Heart, ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";

const Lookbook = () => {
  const navigate = useNavigate();
  const savedLooks: any[] = [];

  return (
    <div className="min-h-screen bg-background">
      <nav className="border-b border-border">
        <div className="container mx-auto px-4">
          <div className="flex items-center h-16">
            <Button variant="ghost" onClick={() => navigate("/")} className="mr-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              돌아가기
            </Button>
            <h1 className="text-xl font-bold tracking-tight">오늘 뭐 입지?</h1>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-12">
        <h2 className="text-4xl font-bold mb-2">내 룩북</h2>
        <p className="text-muted-foreground mb-12">저장한 코디를 모아서 볼 수 있어요</p>

        {savedLooks.length === 0 ? (
          <div className="border border-dashed border-border p-20 text-center max-w-2xl mx-auto">
            <Heart className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">저장된 코디가 없어요</h3>
            <p className="text-muted-foreground mb-8">
              마음에 드는 코디를 저장하고<br />
              나만의 스타일 컬렉션을 만들어보세요!
            </p>
            <Button onClick={() => navigate("/recommendations")}>
              코디 추천받기
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-border">
            {/* Saved looks will be mapped here */}
          </div>
        )}
      </div>
    </div>
  );
};

export default Lookbook;