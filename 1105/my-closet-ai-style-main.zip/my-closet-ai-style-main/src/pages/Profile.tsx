import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";

const Profile = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [height, setHeight] = useState("");
  const [weight, setWeight] = useState("");
  const [gender, setGender] = useState("");
  const [bodyType, setBodyType] = useState("");

  const handleSave = () => {
    if (!height || !weight || !gender || !bodyType) {
      toast({
        title: "필수 항목을 입력해주세요",
        description: "모든 정보를 입력해야 저장할 수 있습니다.",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "프로필이 저장되었습니다",
      description: "이제 나만의 코디를 추천받을 수 있습니다!",
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <nav className="border-b border-border">
        <div className="container mx-auto px-4">
          <div className="flex items-center h-16">
            <Button variant="ghost" onClick={() => navigate("/")} className="mr-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              돌아가기
            </Button>
            <h1 className="text-xl font-bold tracking-tight">오늘 뭐 입지?</h1>
          </div>
        </div>
      </nav>

      <div className="container max-w-2xl mx-auto px-4 py-16">
        <div className="mb-12">
          <h2 className="text-4xl font-bold mb-4">프로필 설정</h2>
          <p className="text-muted-foreground">
            당신에게 맞는 코디를 추천하기 위해 기본 정보가 필요해요
          </p>
        </div>

        <div className="space-y-8 border-t border-border pt-8">
          <div className="space-y-3">
            <Label htmlFor="height" className="text-base font-medium">키 (cm)</Label>
            <Input
              id="height"
              type="number"
              placeholder="170"
              value={height}
              onChange={(e) => setHeight(e.target.value)}
              className="h-12"
            />
          </div>

          <div className="space-y-3">
            <Label htmlFor="weight" className="text-base font-medium">몸무게 (kg)</Label>
            <Input
              id="weight"
              type="number"
              placeholder="60"
              value={weight}
              onChange={(e) => setWeight(e.target.value)}
              className="h-12"
            />
          </div>

          <div className="space-y-3">
            <Label htmlFor="gender" className="text-base font-medium">성별</Label>
            <Select value={gender} onValueChange={setGender}>
              <SelectTrigger id="gender" className="h-12">
                <SelectValue placeholder="선택해주세요" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="male">남성</SelectItem>
                <SelectItem value="female">여성</SelectItem>
                <SelectItem value="other">기타</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-3">
            <Label htmlFor="bodyType" className="text-base font-medium">체형</Label>
            <Select value={bodyType} onValueChange={setBodyType}>
              <SelectTrigger id="bodyType" className="h-12">
                <SelectValue placeholder="선택해주세요" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="straight">스트레이트</SelectItem>
                <SelectItem value="wave">웨이브</SelectItem>
                <SelectItem value="natural">내추럴</SelectItem>
                <SelectItem value="apple">사과형</SelectItem>
                <SelectItem value="hourglass">모래시계형</SelectItem>
                <SelectItem value="rectangle">직사각형</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button onClick={handleSave} className="w-full h-12 text-base mt-12">
            프로필 저장하기
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Profile;