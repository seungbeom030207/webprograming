import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Sparkles, Heart, RefreshCw, ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";

const Recommendations = () => {
  const navigate = useNavigate();
  const [recommendation, setRecommendation] = useState<any>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerate = () => {
    setIsGenerating(true);
    // Simulate AI generation
    setTimeout(() => {
      setRecommendation({
        id: 1,
        items: ["상의", "하의", "신발"],
        colors: {
          main: "#D4A574",
          sub: "#F5F5DC",
          accent: "#8FBC8F",
        },
      });
      setIsGenerating(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-background">
      <nav className="border-b border-border">
        <div className="container mx-auto px-4">
          <div className="flex items-center h-16">
            <Button variant="ghost" onClick={() => navigate("/")} className="mr-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              돌아가기
            </Button>
            <h1 className="text-xl font-bold tracking-tight">오늘 뭐 입지?</h1>
          </div>
        </div>
      </nav>

      <div className="container max-w-5xl mx-auto px-4 py-16">
        <div className="mb-12">
          <h2 className="text-4xl font-bold mb-2">오늘의 코디 추천</h2>
          <p className="text-muted-foreground">
            당신의 옷장에서 최고의 조합을 찾아드릴게요
          </p>
        </div>

        {!recommendation ? (
          <div className="max-w-2xl mx-auto border border-border p-16 text-center">
            <Sparkles className="h-16 w-16 mx-auto mb-6" />
            <h3 className="text-2xl font-semibold mb-4">준비되셨나요?</h3>
            <p className="text-muted-foreground mb-12">
              AI가 당신의 옷장을 분석해서<br />
              오늘 입기 완벽한 코디를 제안해드립니다
            </p>
            <Button
              onClick={handleGenerate}
              disabled={isGenerating}
              className="h-12 px-8"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  생성 중...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-4 w-4" />
                  오늘의 코디 생성하기
                </>
              )}
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="aspect-[3/4] bg-muted flex items-center justify-center">
              <p className="text-muted-foreground">코디 이미지</p>
            </div>

            <div className="space-y-8">
              <div>
                <h3 className="text-xl font-semibold mb-6">추천 색조합</h3>
                <div className="space-y-4">
                  <div>
                    <div
                      className="h-20 mb-2"
                      style={{ backgroundColor: recommendation.colors.main }}
                    />
                    <p className="text-sm text-muted-foreground">메인 컬러</p>
                  </div>
                  <div>
                    <div
                      className="h-20 mb-2"
                      style={{ backgroundColor: recommendation.colors.sub }}
                    />
                    <p className="text-sm text-muted-foreground">서브 컬러</p>
                  </div>
                  <div>
                    <div
                      className="h-20 mb-2"
                      style={{ backgroundColor: recommendation.colors.accent }}
                    />
                    <p className="text-sm text-muted-foreground">포인트 컬러</p>
                  </div>
                </div>
              </div>

              <div className="flex gap-4 pt-4">
                <Button className="flex-1 h-12">
                  <Heart className="mr-2 h-4 w-4" />
                  룩북에 저장
                </Button>
                <Button
                  variant="outline"
                  className="flex-1 h-12"
                  onClick={handleGenerate}
                  disabled={isGenerating}
                >
                  <RefreshCw className="mr-2 h-4 w-4" />
                  다른 코디
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Recommendations;